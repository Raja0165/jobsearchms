![Banner](https://cdn.discordapp.com/attachments/736633764930912257/1011798115499655218/TSWORK.png)
# TSWork - Backend

Job search market for the IT segment


   1. ![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white)
   1. ![NestJS](https://img.shields.io/badge/nestjs-%23E0234E.svg?style=for-the-badge&logo=nestjs&logoColor=white)
   1. ![JWT](https://img.shields.io/badge/JWT-233233.svg?style=for-the-badge&logo=JWT&logoColor=white)
   1. ![MongoDB](https://img.shields.io/badge/MongoDB-%234ea94b.svg?style=for-the-badge&logo=mongodb&logoColor=white)
   1. ![Google Cloud](https://img.shields.io/badge/GoogleCloud-%234285F4.svg?style=for-the-badge&logo=google-cloud&logoColor=white)


