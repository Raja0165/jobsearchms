export class LoginUserDto {
    readonly password: string;
    readonly email: string;
}