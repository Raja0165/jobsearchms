export class AddRoleUserDto {
    readonly email: string;
    readonly role: string;
}