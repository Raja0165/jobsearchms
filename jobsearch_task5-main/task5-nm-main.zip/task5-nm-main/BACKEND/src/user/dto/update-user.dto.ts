export class UpdateUserDto {
    readonly name: string;
    readonly surname: string;
    readonly github: string;
    readonly email: string;
    readonly number: string;
}