export class CreateUserDto {
    readonly name: string;
    readonly surname: string;
    readonly password: string;
    readonly github: string;
    readonly email: string;
    readonly number: string;
}