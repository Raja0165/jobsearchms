export type tokensDbType = {
  email: string;
  refreshToken: string;
}